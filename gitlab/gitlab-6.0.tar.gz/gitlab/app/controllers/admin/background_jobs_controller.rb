class Admin::BackgroundJobsController < Admin::ApplicationController
  def show
  end
end
