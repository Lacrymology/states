class ErrorsController < ApplicationController
end
